//
//  zlamov.c
//
//  Written by Lee Killough 04/19/2012
//  

#define TYPE  complex16
#define FUNC  "ZLAMOV"
#define LAMOV zlamov_
#define LACPY zlacpy_
#include "lamov.h"
