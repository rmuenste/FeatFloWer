//
//  dlamov.c
//
//  Written by Lee Killough 04/19/2012
//  

#define TYPE  double
#define FUNC  "DLAMOV"
#define LAMOV dlamov_
#define LACPY dlacpy_
#include "lamov.h"
